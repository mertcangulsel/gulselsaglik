<?php
// buraya sesion ve bağlantı yaz ayarlarını yaz



$baglan=mysqli_connect("localhost","mertcan","123456","gulselsaglik");
?>

