<!DOCTYPE html/>
<html lang="us">
<head>
<meta charset="UTF-8">
<title> Yönetim Bilişim Sistemleri Admin Panel</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>

<body>
<div class="container">
<form  class="form-signin" action="kontrol.php" method="POST"> 
<h2 class="form-signin-heading">Admin Panel</h2>
	<input type="email" name="inputEmail" class="form-control" required autofocus>
	<input type="password" name="inputSifre" class="form-control" required>
	<button type="submit" class="btn-primary btn  btn-lg btn-block">Giriş</button>
</form>
</div>
</body>
</html>