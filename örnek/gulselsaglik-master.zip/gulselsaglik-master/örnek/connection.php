<?php
$baglan=mysqli_connect("localhost","root","","mis");
?>