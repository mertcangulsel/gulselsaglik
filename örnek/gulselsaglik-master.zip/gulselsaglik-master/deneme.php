<html>

<head>
  <meta charset="UTF-8">
  <title>Gülsel sağlık giriş</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link href="css/signin.css" rel="stylesheet">
  <script src="js/prefixfree.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <div class="container">
       <h1 class="form-signin-heading">Gülsel Sağlık</h1> 
    </div>
    <div class="container">
<form class= "form-signin" action="denetle.php" method="POST">
    <h2 class="form-signin-heading">Hoşgeldiniz</h2>
    <input type="email" name="email" class="form-control" placeholder="E-Posta" required autofocus> 
    <input type="password" name="acarsoz" class="form-control" placeholder="Açarsöz" required >
    <button type="submit" class="btn btn-lg btn-primary btn-block">giriş</button>

</form>
        </div>
</body>
</html>
